This folder is used to store Repair_Kits for the Custom_Durability feature.

More info here: https://cjcrafter.gitbook.io/weaponmechanics/weapon-modules/shoot/custom-durability